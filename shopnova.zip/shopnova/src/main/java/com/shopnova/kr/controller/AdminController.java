package com.shopnova.kr.controller;

import java.math.BigDecimal;
import java.util.Arrays;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.shopnova.kr.domain.Payment;
import com.shopnova.kr.domain.Products;
import com.shopnova.kr.domain.User;
import com.shopnova.kr.repository.UserRepository;
import com.shopnova.kr.service.PaymentService;
import com.shopnova.kr.service.ProductsService;
import com.shopnova.kr.service.UserService;

import jakarta.servlet.http.HttpSession;

@Controller
@RequestMapping("/admin")
public class AdminController {
	
	
    @Autowired
    private PaymentService paymentService;

    @Autowired
    private UserRepository userRepository;
    
    @Autowired
	private ProductsService productsService; 
    
    @Autowired
    private UserService userService;

    // 관리자 페이지로 이동 (로그인된 사용자의 정보로 처리)

 // 관리자 페이지로 이동 (로그인된 사용자의 정보로 처리)
    @GetMapping("/adminpage")
    public String showAdminUserPage(HttpSession session, Model model) {
        // 세션에서 로그인된 사용자 정보 가져오기
        User sessionUser = (User) session.getAttribute("currentUser");

        // 로그인되지 않았거나 관리자 권한이 아닌 경우
        if (sessionUser == null || !"ADMIN".equals(sessionUser.getRole())) {
            return "redirect:/users/login";  // 로그인 페이지로 리디렉션
        }

        // 모든 사용자 목록을 가져와서 모델에 추가
        List<User> users = userRepository.findAll();
        model.addAttribute("users", users);

        // 관리자 페이지 템플릿 반환 (사용자 목록을 포함한 관리자 페이지)
        return "admin/adminpage"; 
    }

    // 사용자 상태 변경
    @PostMapping("/update-status")
    public String updateUserStatus(@RequestParam("userId") Long userId, RedirectAttributes redirectAttributes) {
        try {
            userService.toggleUserStatus(userId);  // 사용자 상태 토글 (활성화/비활성화)
            redirectAttributes.addFlashAttribute("message", "사용자 상태가 변경되었습니다.");
        } catch (Exception e) {
            redirectAttributes.addFlashAttribute("message", "사용자 상태 변경 중 오류가 발생했습니다.");
        }
        // 상태 변경 후 관리자 페이지로 리디렉션
        return "redirect:/admin/adminpage";
    }


    @PostMapping("/deleteUser")
    public String deleteUser(@RequestParam("userId") Long userId, RedirectAttributes redirectAttributes) {
        try {
            userService.deleteUser(userId);
            redirectAttributes.addFlashAttribute("message", "사용자가 삭제되었습니다.");
        } catch (Exception e) {
            redirectAttributes.addFlashAttribute("error", "사용자 삭제 중 오류 발생!");
        }
        return "redirect:/admin/adminpage";
    }
    
    @GetMapping("/sales")
    public String showSales(Model model) {
        // 결제 데이터 조회
        List<Payment> payments = paymentService.getAllPayments();  // 모든 결제 데이터 조회

        // 총 결제 금액 계산
        BigDecimal totalSales = payments.stream()
                                        .map(payment -> {
                                            // paymentAmount를 String에서 BigDecimal로 변환
                                            if (payment.getPaymentAmount() != null) {
                                                return new BigDecimal(payment.getPaymentAmount());
                                            } else {
                                                return BigDecimal.ZERO;  // paymentAmount가 null일 경우 0으로 처리
                                            }
                                        })
                                        .reduce(BigDecimal.ZERO, BigDecimal::add);  // 결제 금액 합산

        // 모델에 데이터 추가
        model.addAttribute("payments", payments);
        model.addAttribute("totalSales", totalSales);

        return "admin/sales";  // sales 페이지로 이동
    }

}
