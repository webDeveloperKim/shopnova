package com.shopnova.kr.domain;

public enum ProductsStatus {
	READY, EXHAUSTION, AVAILABLE
}
