package com.shopnova.kr.service;

import java.security.SecureRandom;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import java.util.regex.Pattern;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.mail.javamail.MimeMessageHelper;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.ui.Model;
import org.springframework.web.client.RestTemplate;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.shopnova.kr.domain.User;
import com.shopnova.kr.repository.CartItemsRepository;
import com.shopnova.kr.repository.OrderRepository;
import com.shopnova.kr.repository.PaymentRepository;
import com.shopnova.kr.repository.UserRepository;

import jakarta.mail.internet.MimeMessage;
import jakarta.servlet.http.HttpSession;

@Service
public class UserService {
	
	@Autowired
    private UserRepository userRepository;
	
	@Autowired
    private  CartItemsRepository cartItemsRepository;
	
	@Autowired
    private JavaMailSender mailSender;
	
	 @Autowired
	private OrderRepository orderRepository;
	 
	 @Autowired
	private PaymentRepository paymentRepository;

    // 비밀번호 재설정 토큰을 저장하는 맵 (실제로는 DB 사용해야 함)
    private Map<String, String> passwordResetTokens = new HashMap<>();
    
    public User authenticate(String email, String password, HttpSession session) {
        return login(email, password, session);  // 기존 login 메서드를 재사용
    }
    
    public boolean checkLoginStatus(HttpSession session) {
        return session.getAttribute("user") != null;
    }
    
    // id 조회!
    public User findById(Long currentUser) {
        return userRepository.findById(currentUser).orElse(null);
    }
  
    // 로그인 처리
    public User login(String email, String password, HttpSession session) {
        User user = findUserByEmail(email);
        if (user != null && password.equals(user.getPassword())) {
            session.setAttribute("user", user);
            return user;
        }
        return null;
    }

 // 회원가입 처리
    public User signUp(User user, HttpSession session) {
        user.setRole("USER"); // 문자열로 ROLE 설정
        user.setStatus("ACTIVE"); // 문자열로 상태 설정

        if (findUserByEmail(user.getEmail()) != null) {
            return null;
        }
        if (!isValidEmail(user.getEmail()) || !isValidPassword(user.getPassword())) {
            return null;
        }
        user = saveUser(user);
        session.setAttribute("user", user);
        return user;
    }

    // 로그아웃 처리
    public void logout(HttpSession session) {
        session.invalidate();
    }

    // 이메일로 사용자 찾기
    public User findUserByEmail(String email) {
        return userRepository.findByEmail(email);
    }
    
    // 번호로 사용자 이메일 찾기
    public User findUserByPhone(String phone) {
        return userRepository.findByPhone(phone);
    }
    
    public String findUserByPhoneNumber(String phone) {
    	User user = findUserByPhone(phone);
    	if (user != null) {
    		return user.getEmail();
    	}
    	return null;
    }

    // 이메일 중복 체크
    public boolean isEmailExist(String email) {
        return findUserByEmail(email) != null;
    }
    
    // 사용자 정보를 DB에 저장
    public User saveUser(User user) {
        return userRepository.save(user);
    }

    // 랜덤 비밀번호 생성 (6~8자리)
    public String generateRandomPassword() {
        int length = 6;
        String passwordCharacters = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789!@#$%^&*()_+";
        SecureRandom random = new SecureRandom();
        StringBuilder password = new StringBuilder(length);

        for (int i = 0; i < length; i++) {
            int index = random.nextInt(passwordCharacters.length());
            password.append(passwordCharacters.charAt(index));
        }
        return password.toString();
    }

    // 비밀번호 업데이트
    public boolean updatePassword(String email, String newPassword) {
        User user = findUserByEmail(email);
        if (user != null) {
            user.setPassword(newPassword);
            saveUser(user);
            return true;
        }
        return false;
    }

    // 비밀번호 재설정 링크 이메일 발송
    public void sendPasswordResetLink(String email) {
        String token = UUID.randomUUID().toString();
        passwordResetTokens.put(token, email); // 토큰 저장
        sendPasswordResetEmail(email, token);
    }

    public void sendPasswordResetEmail(String email, String token) {
        try {
            String subject = "Password Reset Request";
            
            // HTML 형식으로 이메일 본문 작성
            String content = "<html><body>" +
                    "<p>To reset your password, click the link below:</p>" +
                    "<a href=\"http://www.shopnova.kr/users/resetPW?token=" + token + "\">Reset Password</a>" +
                    "</body></html>";


            // 이메일 메시지 생성
            MimeMessage message = mailSender.createMimeMessage();
            MimeMessageHelper helper = new MimeMessageHelper(message, true);

            // 수신자, 제목, 본문 설정
            helper.setTo(email);
            helper.setSubject(subject);
            helper.setText(content, true);  // true를 설정하면 HTML 형식으로 처리됨

            // 이메일 발송
            mailSender.send(message);
            System.out.println("Password reset email sent to " + email + " with token: " + token);
        } catch (Exception e) {
            e.printStackTrace();
            System.out.println("Failed to send password reset email.");
        }
    }


    public boolean resetPW(String token, String newPassword, String confirmPassword) {
        // 비밀번호가 일치하지 않으면 실패
        if (!newPassword.equals(confirmPassword)) {
            return false;  // 비밀번호 불일치
        }

        // 토큰을 통해 이메일을 찾기
        String email = getEmailByToken(token);  // 저장된 토큰에서 이메일 찾기

        if (email == null) {
            return false;  // 토큰이 유효하지 않거나 만료된 경우
        }

        // 이메일로 사용자 찾기
        User user = findUserByEmail(email);  // 이메일로 사용자 조회

        if (user == null) {
            return false;  // 사용자가 존재하지 않으면 실패
        }

        // 비밀번호 업데이트
        user.setPassword(newPassword);
        saveUser(user);  // 비밀번호 변경 후 DB에 저장

        // 토큰 제거 (비밀번호 변경 후 더 이상 유효하지 않으므로)
        passwordResetTokens.remove(token);

        return true;  // 비밀번호 변경 성공
    }

    // 토큰을 기반으로 이메일을 찾는 메서드
    public String getEmailByToken(String token) {
        return passwordResetTokens.get(token); // 저장된 토큰에서 이메일 반환
    }

   
 // 기존 메서드를 수정하여 수정할 사용자 정보를 직접 받도록 변경
    public boolean updateUserProfile(Long userId, String name, String phone, String address, String email) {
        // 1. ID로 사용자 검색
        User existingUser = userRepository.findById(userId).orElse(null);
        
        if (existingUser != null) {
            // 2. 사용자 정보 수정 (새로 입력된 정보로 변경)
            
            // 이메일 변경 시 이메일 중복 체크
            if (email != null && !email.equals(existingUser.getEmail()) && isEmailExist(email)) {
                // 이미 존재하는 이메일이면 수정 불가
                return false;
            }
            
            // 이메일이 변경되었을 경우에만 수정
            if (email != null && !email.equals(existingUser.getEmail())) {
                existingUser.setEmail(email);
            }
            
            // 나머지 필드들 업데이트
            existingUser.setName(name);
            existingUser.setPhone(phone);
            existingUser.setAddress(address);

            // 3. 수정된 정보 저장
            userRepository.save(existingUser);
            return true; // 수정 성공
        }
        
        return false; // 사용자 정보가 존재하지 않으면 수정 실패
    }


    // 이메일 형식 유효성 검증
    private boolean isValidEmail(String email) {
        String emailRegex = "^[a-zA-Z0-9_+&*-]+@[a-zA-Z0-9-]+(?:\\.[a-zA-Z]{2,})?$";
        Pattern pattern = Pattern.compile(emailRegex);
        return pattern.matcher(email).matches();
    }

    // 비밀번호 형식 유효성 검증
    private boolean isValidPassword(String password) {
        return password.length() >= 6;
    }
    
    // 모든 사용자 목록 가져오기
    public List<User> getAllUsers() {
        return userRepository.findAll();  // 데이터베이스에서 모든 사용자 리스트 반환
    }

    // 회원 상태 변경 (활성화/비활성화)
 // 회원 상태 변경 (활성화/비활성화)
    public boolean updateUserStatus(Long userId, String status) {
        // 사용자 조회
        User user = userRepository.findById(userId).orElse(null);
        
        if (user != null) {
            // status 값이 "ACTIVE" 또는 "INACTIVE"인지 확인
            if ("ACTIVE".equalsIgnoreCase(status) || "INACTIVE".equalsIgnoreCase(status)) {
                user.setStatus(status);  // 상태 변경
                userRepository.save(user);  // 상태 업데이트 후 저장
                return true;
            } else {
                // 잘못된 status 값이 들어왔을 경우 예외 처리
                System.out.println("Invalid status value: " + status);
                return false;
            }
        }
        return false;
    }
    
    public void toggleUserStatus(Long userId) {
        // 사용자 정보 가져오기
        User user = userRepository.findById(userId).orElseThrow(() -> new IllegalArgumentException("사용자를 찾을 수 없습니다."));

        // 상태를 active ↔ inactive로 토글
        if ("ACTIVE".equals(user.getStatus())) {
            user.setStatus("INACTIVE");  // active 상태 -> inactive로 변경
        } else {
            user.setStatus("ACTIVE");    // inactive 상태 -> active로 변경
        }

        // 상태 변경된 사용자 저장
        userRepository.save(user);
    }

    public User getUserById(Long id) {
        return userRepository.findById(id).orElse(null); // ID로 유저 조회
    }

    @Transactional
    public void deleteUser(Long userId) {
        if (userRepository.existsById(userId)) {
            // 1. 먼저 payment 테이블에서 해당 사용자의 주문 관련 결제 정보 삭제
            paymentRepository.deleteByOrderUserId(userId);

            // 2. 그 후 orders 테이블에서 사용자의 주문 삭제
            orderRepository.deleteByUserId(userId);

            // 3. 그리고 cart_items 테이블에서 사용자의 장바구니 아이템 삭제
            cartItemsRepository.deleteByUserId(userId);

            // 4. 마지막으로 users 테이블에서 사용자 삭제
            userRepository.deleteById(userId);
        } else {
            throw new RuntimeException("해당 ID의 사용자를 찾을 수 없습니다.");
        }
    }
    
    // 예시로 사용자 정보를 가져오는 메소드
    public User getCurrentUser() {
        // 예시로 하드코딩된 사용자 정보 반환. 실제로는 DB나 세션에서 사용자 정보를 가져옴
        return new User(null, "홍길동", "123-456-7890", "서울시 강남구", "hong@example.com", null, null, null, null);
    }
    // ✅ 메서드 이름을 findUserById로 맞춤
    public User findUserById(Long userId) {
        return userRepository.findById(userId).orElse(null);
    }
    public User findByEmail(String email) {
        // 이메일로 사용자 검색 로직 구현 (예: 데이터베이스에서 이메일로 사용자 찾기)
        return userRepository.findByEmail(email);
    }
    
    

 
}


