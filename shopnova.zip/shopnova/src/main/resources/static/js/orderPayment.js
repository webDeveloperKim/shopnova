// 안전한 UUID 생성 함수
function generateUUID() {
    if (window.crypto && crypto.randomUUID) {
        return crypto.randomUUID();
    }
    return uuidv4();
}

// 비동기 결제 요청 함수
async function startPayment(productNames, totalAmount, recipientName, phoneNumber, address) {
    var IMP = window.IMP;
    IMP.init("imp61658385"); // 본인의 가맹점 코드로 교체

    var merchantUid = `payment-${generateUUID()}`;
    console.log("생성된 주문번호:", merchantUid);

    try {
        const response = await new Promise((resolve, reject) => {
            IMP.request_pay(
                {
                    channelKey: "channel-key-bfffb065-68a2-4413-8c29-489105f3b4f3",
                    pay_method: "card",
                    merchant_uid: merchantUid,
                    name: productNames.join(", "),
                    amount: totalAmount,
                    buyer_name: recipientName,
                    buyer_tel: phoneNumber,
                    buyer_addr: address,
                },
                function (rsp) {
                    if (rsp.success) {
                        resolve(rsp);
                    } else {
                        reject(new Error(`결제 실패: ${rsp.error_msg}`));
                    }
                }
            );
        });

        alert("결제 성공!");
        console.log("결제 성공:", response);

        // 서버에 결제 정보 전송
        const requestBody = {
            merchantUid: merchantUid,
            impUid: response.imp_uid,
            amount: totalAmount,
            buyerName: recipientName,
            buyerPhone: phoneNumber,
            buyerAddress: address,
            products: productNames,
        };

        console.log("서버로 보낼 데이터:", requestBody);

        const serverResponse = await fetch("/api/payment/confirm", {
            method: "POST",
            headers: {
                "Content-Type": "application/json",
            },
            body: JSON.stringify(requestBody),
        });

        const result = await serverResponse.json();
        console.log("서버 응답:", result);

        if (!serverResponse.ok) {
            throw new Error(`서버 오류: ${result.message || "알 수 없는 오류"}`);
        }

        // 결제 성공 후 폼 제출
        document.querySelector("form").submit();
    } catch (error) {
        alert(error.message);
        console.error("결제 요청 중 오류 발생:", error);
    }
}

// 결제하기 버튼 클릭 시 실행되는 함수
$("#checkout-button").on("click", function (event) {
    event.preventDefault();

    var recipientName = $("input[name='recipientName']").val();
    var address = $("input[name='address']").val();
    var phoneNumber = $("input[name='phoneNumber']").val();
    var totalAmount = parseInt($("input[name='totalAmount']").val(), 10);

    let productNames = [];

    $(".order-item").each(function () {
        const productName = $(this).find(".order-item-details p:first-child").text().trim();
        const priceText = $(this).find(".order-item-details p span").first().text().trim();
        const quantityText = $(this).find("span[id^='product-'][id$='-quantity']").text().trim();

        const quantity = parseInt(quantityText, 10);
        const price = parseInt(priceText.replace(/[^0-9]/g, ""), 10);

        if (!isNaN(price) && !isNaN(quantity)) {
            productNames.push(productName);
        }
    });

    if (totalAmount <= 0) {
        alert("결제할 상품이 없습니다.");
        return;
    }

    if (!recipientName.trim() || !address.trim() || !phoneNumber.trim()) {
        alert("배송 정보를 모두 입력해주세요.");
        return;
    }

    alert(`총 결제 금액은 ${totalAmount.toLocaleString()} 원 입니다.`);

    startPayment(productNames, totalAmount, recipientName, phoneNumber, address);
});
