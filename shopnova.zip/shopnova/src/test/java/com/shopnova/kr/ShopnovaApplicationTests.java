package com.shopnova.kr;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ShopnovaApplicationTests {

	@Test
	void contextLoads() {
	}

}
